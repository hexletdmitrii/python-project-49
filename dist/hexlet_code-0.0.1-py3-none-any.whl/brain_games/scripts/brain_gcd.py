from brain_games.engine import engine


def main():
    engine('gcd', 'Find the greatest common divisor of given numbers.')