#!/usr/bin/env python3
import brain_games.cli

def main():
    print('Welcome to the Brain Games!')
    welcome_user()
