from brain_games.engine import engine


def main():
    engine('prime', '''Answer "yes" if given number is \
prime. Otherwise answer "no".''')
