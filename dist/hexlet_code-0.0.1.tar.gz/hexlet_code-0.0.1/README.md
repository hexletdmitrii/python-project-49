### Hexlet tests and linter status:
[![Actions Status](https://github.com/hexletdmitrii/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/hexletdmitrii/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/e157bb4865364f69207a/maintainability)](https://codeclimate.com/github/hexletdmitrii/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/1eVdmxT5GFb03RyCipSX5fjXB.svg)](https://asciinema.org/a/1eVdmxT5GFb03RyCipSX5fjXB)
[![asciicast](https://asciinema.org/a/Qwk2t3eNIqSRvrZmHfyVoBnrx.svg)](https://asciinema.org/a/Qwk2t3eNIqSRvrZmHfyVoBnrx)
[![asciicast](https://asciinema.org/a/J8YAM9yReGsCBOzCaQHfWWnZ3.svg)](https://asciinema.org/a/J8YAM9yReGsCBOzCaQHfWWnZ3)
[![asciicast](https://asciinema.org/a/hJZIxjXsj7iycozOzqraoMjEh.svg)](https://asciinema.org/a/hJZIxjXsj7iycozOzqraoMjEh)
[![asciicast](https://asciinema.org/a/Ql7howi8WDf9XY7kThZtdlnPR.svg)](https://asciinema.org/a/Ql7howi8WDf9XY7kThZtdlnPR)
