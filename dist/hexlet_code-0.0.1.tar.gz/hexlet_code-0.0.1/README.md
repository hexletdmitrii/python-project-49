### Hexlet tests and linter status:
[![Actions Status](https://github.com/hexletdmitrii/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/hexletdmitrii/python-project-49/actions)
(https://codeclimate.com/github/hexletdmitrii/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/e157bb4865364f69207a/maintainability)
[![asciicast](https://asciinema.org/a/1eVdmxT5GFb03RyCipSX5fjXB.svg)](https://asciinema.org/a/1eVdmxT5GFb03RyCipSX5fjXB)
