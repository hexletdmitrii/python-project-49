from brain_games.engine import engine


def main():
    engine('progression', 'What number is missing in the progression?')
