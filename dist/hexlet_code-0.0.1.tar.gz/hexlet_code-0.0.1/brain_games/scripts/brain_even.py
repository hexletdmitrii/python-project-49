from brain_games.engine import engine


def main():
    engine('even', 'Answer "yes" if the number is even, otherwise answer "no".')
