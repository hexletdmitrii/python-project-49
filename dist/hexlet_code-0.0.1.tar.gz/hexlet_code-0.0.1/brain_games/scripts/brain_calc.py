from brain_games.cli import welcome_user
from random import randint


def main():
    print('Welcome to the Brain Games!')
    name = welcome_user()
    print(f'Hello, {name}!')
    print('What is the result of the expression?')
    for i in range(3):
        random_num1 = randint(1, 99)
        random_operator = choice(['*', '+', '-'])
        if random_operator != '*':
            random_num2 = randint(1, 99)
        else:
            random_num2 = randint(1, 10)
        match random_operator:
            case "*":
                contr = random_num1 * random_num2
            case "+":
                contr = random_num1 + random_num2
            case "-":
                contr = random_num1 - random_num2
        
        print(f'Question: {str(random_num1) + str(random_operator) + str(random_num2)}')
        ans = input('Your answer: ')
        if ans != contr:
            print(f"'{ans}' is wrong answer ;(. Correct answer was '{contr}'.")
            print(f"Let's try again, {name}!")
            return
    return print(f'Congratulations, {name}!')
